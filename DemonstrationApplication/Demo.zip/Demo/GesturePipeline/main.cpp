#include "Common.h"
#include "Pipeline.h"

int main() {
	Pipeline program;
	program.Execute();

	return 0;
}